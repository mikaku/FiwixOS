# color-ls initialization

# Skip all for noninteractive shells.
[ ! -t 0 ] && return

eval `dircolors --sh /etc/DIR_COLORS`

