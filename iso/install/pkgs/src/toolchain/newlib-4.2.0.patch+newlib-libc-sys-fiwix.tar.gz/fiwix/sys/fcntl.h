#ifndef FCNTL_H
#ifdef __cplusplus
extern "C" {
#endif
#define FCNTL_H

#include <sys/types.h>

/* open/fcntl - O_SYNC is only implemented on blocks devices and on files
   located on an ext2 file system */
#define O_ACCMODE	   0003
#define O_RDONLY	     00
#define O_WRONLY	     01
#define O_RDWR		     02
#define O_CREAT		   0100	/* not fcntl */
#define O_EXCL		   0200	/* not fcntl */
#define O_NOCTTY	   0400	/* not fcntl */
#define O_TRUNC		  01000	/* not fcntl */
#define O_APPEND	  02000
#define O_NONBLOCK	  04000
#define O_NDELAY	O_NONBLOCK
#define O_SYNC		 010000
#define FASYNC		 020000	/* fcntl, for BSD compatibility */
#define O_DIRECT         040000 /* direct disk access hint */
#define O_LARGEFILE     0100000
#define O_DIRECTORY     0200000 /* must be a directory */
#define O_NOFOLLOW      0400000 /* don't follow links */
#define O_CLOEXEC      02000000	/* set close_on_exec */

#define F_DUPFD		0	/* dup */
#define F_GETFD		1	/* get f_flags */
#define F_SETFD		2	/* set f_flags */
#define F_GETFL		3	/* more flags (cloexec) */
#define F_SETFL		4
#define F_GETLK		5
#define F_SETLK		6
#define F_SETLKW	7
#define F_DUPFD_CLOEXEC	1030

#define F_SETOWN	8	/*  for sockets. */
#define F_GETOWN	9	/*  for sockets. */

/* for F_[GET|SET]FL */
#define FD_CLOEXEC	1	/* actually anything with low bit set goes */

/* for posix fcntl() and lockf() */
#define F_RDLCK		0
#define F_WRLCK		1
#define F_UNLCK		2

/* for old implementation of bsd flock () */
#define F_EXLCK		4	/* or 3 */
#define F_SHLCK		8	/* or 4 */

/* operations for bsd flock(), also used by the kernel implementation */
#define LOCK_SH		1	/* shared lock */
#define LOCK_EX		2	/* exclusive lock */
#define LOCK_NB		4	/* or'd with one of the above to prevent
				   blocking */
#define LOCK_UN		8	/* remove lock */

/* IEEE Std 1003.1, 2004 Edition */
struct flock {
	short int l_type;	/* type of lock: F_RDLCK, F_WRLCK, F_UNLCK */
	short int l_whence;	/* flag for 'l_start': SEEK_SET, SEEK_CUR, ...*/
	__off_t l_start;	/* relative offset in bytes */
	__off_t l_len;		/* size; if 0 then until EOF */
	__pid_t l_pid;		/* PID holding the lock; returned in F_GETLK */
};


extern int open(const char *, int, ...);
extern int creat(const char *, mode_t);
extern int fcntl(int, int, ...);
extern int flock(int, int);

#ifdef __cplusplus
}
#endif
#endif /* FCNTL_H */
