#ifndef _SYS_VFS_H
#define _SYS_VFS_H

#include <sys/statfs.h>

//extern int statfs(const char *, struct statfs *);
//int	statfs(const char * __path, struct statfs * __buf);

#endif /* _SYS_VFS_H */
