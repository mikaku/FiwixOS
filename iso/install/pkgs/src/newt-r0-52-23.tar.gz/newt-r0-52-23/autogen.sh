#!/bin/sh

autoheader
autoconf
make -C po
