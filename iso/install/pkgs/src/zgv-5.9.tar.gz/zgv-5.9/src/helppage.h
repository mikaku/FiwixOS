/* Zgv v3.1 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1998 Russell Marks. See README for license details.
 *
 * helppage.h - prototype for showhelp() from helppage.c.
 */

extern void showhelp(int ttyfd,char *title,char *help[]);
