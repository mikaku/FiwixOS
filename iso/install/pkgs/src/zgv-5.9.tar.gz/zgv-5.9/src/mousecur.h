/* Zgv v3.1 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1998 Russell Marks. See README for license details.
 *
 * mousecur.h - defines for mousecur.c
 */

extern void mousecur_init(int blackcol,int whitecol);
extern void mousecur_on(void);
extern void mousecur_off(void);
