/* Zgv v3.1 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1998 Russell Marks. See README for license details.
 *
 * copymove.h
 */

extern int copyfile(char *src,char *dstdir);
extern int movefile(char *src,char *dstdir);
