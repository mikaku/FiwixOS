/* Zgv v3.1 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1998 Russell Marks. See README for license details.
 *
 * gnuhelp.h - prototypes for stupid GNUisms.
 */

extern void gnu_init_help(int ttyfd);
extern void gnu_warranty_help(int ttyfd);
