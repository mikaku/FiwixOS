
#include "doomdef.h"


int main( int argc, char** argv )
{
  myargc = argc;
  myargv = argv;
  
  D_DoomMain ();
  
  return 0;
}
