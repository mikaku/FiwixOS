#ifndef __CT_CHAT__
#define __CT_CHAT__


/*
 * Chat mode stuff
 */

#define CT_PLR_GREEN	        1
#define CT_PLR_YELLOW	        2
#define CT_PLR_RED		3
#define CT_PLR_BLUE		4
#define CT_PLR_ALL		5

#define CT_KEY_GREEN	        'g'
#define CT_KEY_YELLOW	        'y'
#define CT_KEY_RED		'r'
#define CT_KEY_BLUE		'b'
#define CT_KEY_ALL		't'


#endif   /* __CT_CHAT__ */
