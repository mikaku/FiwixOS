Activision and Raven are releasing this code for people to learn from and play with.
The code is retains its original copyright and can not be used for profit, 
any work released using this code must contain credit for it.

Issues:
The DMX sound library is not included with the source due to license issues,
so you won't be able to link until those sound calls are replaced or removed.