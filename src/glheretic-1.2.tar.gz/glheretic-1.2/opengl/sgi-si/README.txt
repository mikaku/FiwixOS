
The library libtess was taken directly from the open-sourced SGI OpenGL sample-
implementation (SI). For a license of this lib
look at http://oss.sgi.com/projects/FreeB.

As soon as the tessellation functions in Mesa are working properly, I will
use these instead. Until then I hope it works fine this way.

-Andre Werthmann.
