static char	ident[] = "@(#)(N)compress 5.0";
#define	version_id (ident+4)
