Contabilidad General Spectrum.tzx: original converted tape. Needs a previous CLEAR 59999 then LOAD ""
Contabilidad General Spectrum_con_clear.tzx: same program as before but it has the CLEAR 59999 and loads automatically
Contabilidad General Spectrum_con_clear.tap: same program as before but in tap format

ajedrez: seems to be a modified version of Masterchess of mikro-gen
